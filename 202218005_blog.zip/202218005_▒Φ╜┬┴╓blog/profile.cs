﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Reflection.Emit;

namespace _202218005_김승주blog
{
    public partial class profile : Form
    {
        private string userID;

        public profile(string userID)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.userID = userID;

            //폼이 로드될 때, 현재 유저정보 표시
            ID.Text = userID;
            Tel.Text = GetTelByID(userID);
            Birth.Text = GetBirthByID(userID);
        }

        //전화번호를 db에서 조회
        private string GetTelByID(string userID)
        {
            string tel = string.Empty;
            string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT tel FROM Town WHERE id = @ID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", userID);
                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        tel = result.ToString();
                    }
                }
            }

            return tel;
        }

        //생년월일을 db에서 조회
        private string GetBirthByID(string userID)
        {
            string birth = string.Empty;
            string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT birth FROM Town WHERE id = @ID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", userID);
                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        birth = result.ToString();
                    }
                }
            }
            return birth;
        }


        private void btnYes_Click(object sender, EventArgs e)
        {
            revise reviseForm = new revise(userID);
            reviseForm.Show();
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
