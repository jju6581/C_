﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace _202218005_김승주blog
{
    public partial class WriteForm : Form
    {
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";
        // 현재 유저id 저장하는 변수
        private string currentID;

        // 다른 폼으로부터 메모를 업데이트하기 위한 이벤트
        public event Action<string, string> UpdateTimelineLabelAndTextBox;

        // TimelineForm 참조를 저장하는 변수
        private Timeline timelineForm;

        public WriteForm(string userID, Timeline timeline)
        {
            InitializeComponent();
            currentID = userID;
            timelineForm = timeline; 
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void writeForm_Load(object sender, EventArgs e)
        {

        }

        //textbox 내용이 변경될 때 호출
        private void textBox_TextChanged(object sender, EventArgs e)
        {
            int currentLength = textBox.Text.Length;

            // 글자 80자 초과시 자르고 빨간색으로 표시됨
            if (currentLength > 80)
            {
                textBox.Text = textBox.Text.Substring(0, 80);
                textBox.SelectionStart = textBox.Text.Length;
                btnSave.Enabled = false;
                gay.ForeColor = Color.Red;
            }
            else
            {
                btnSave.Enabled = true;
                gay.ForeColor = Color.White;
            }

            //글자 수 표시
            if (currentLength == 0)
            {
                gay.Text = "";
            }
            else
            {
                gay.Text = $"{currentLength}/80";
            }
        }

        //메모저장
        private void btnSave_Click_1(object sender, EventArgs e)
        {
            //80자 이내인 경우만 저장
            if (textBox.Text.Length <= 80)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Memo 테이블에 데이터 삽입
                    string query = "INSERT INTO Memo (id, memo, created_at) VALUES (@ID, @Memo, @CreatedAt)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID", currentID);
                        command.Parameters.AddWithValue("@Memo", textBox.Text);
                        command.Parameters.AddWithValue("@CreatedAt", DateTime.Now);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("업로드 완료.", "저장 완료", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            UpdateTimelineLabelAndTextBox?.Invoke(currentID, textBox.Text); 
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("업로드 실패.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("글 작성은 80자까지만 가능합니다.", "글 작성 실패", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

    }
}
