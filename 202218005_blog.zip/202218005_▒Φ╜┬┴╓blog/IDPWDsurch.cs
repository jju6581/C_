﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _202218005_김승주blog
{
    public partial class IDPWDsurch : Form
    {
        // 데이터베이스 연결
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";

        public IDPWDsurch()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        //id surch
        private void btnYes_Click(object sender, EventArgs e)
        {
            string tel = Tel.Text;
            string birth = Birth.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // 입력된 전화번호와 생년월일로 일치하는 ID조회
                string query = "SELECT id FROM Town WHERE tel = @Tel AND birth = @Birth";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Tel", tel);
                    command.Parameters.AddWithValue("@Birth", birth);

                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        string id = result.ToString();
                        MessageBox.Show("ID: " + id + "입니다", "검색 결과", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("일치하는 정보가 없습니다.", "검색 결과", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        //pwd surch
        private void btnYes2_Click(object sender, EventArgs e)
        {
            string id = ID.Text;
            string tel = Tel2.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // 입력된 ID와 전화번호로 일치하는 ID조회
                    string query = "SELECT pwd FROM Town WHERE id = @ID AND tel = @Tel";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID", id);
                        command.Parameters.AddWithValue("@Tel", tel);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            string pwd = result.ToString();
                            MessageBox.Show("PWD: " + pwd + "입니다", "검색 결과", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("일치하는 정보가 없습니다.", "검색 결과", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("데이터베이스 연결 중 오류가 발생했습니다: " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void IDPWDsurch_Load(object sender, EventArgs e)
        {

        }
    }
}