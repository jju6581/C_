﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _202218005_김승주blog
{
    public partial class Insert : Form
    {
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";

        public Insert()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            // 입력한 정보 가져오기
            string id = ID.Text;
            string pwd = PWD.Text;
            string tel = Tel.Text;
            string birth = Birth.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // 동일한 ID있는지 확인
                string checkQuery = "SELECT COUNT(*) FROM Town WHERE id = @ID";
                using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@ID", id);
                    int existingCount = (int)checkCommand.ExecuteScalar();

                    if (existingCount > 0)
                    {
                        // 이미 존재하는 ID일시 알림창
                        MessageBox.Show("이미 존재하는 ID입니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // 없는 ID일 경우 데이터를 Town 테이블에 넣는다
                string query = "INSERT INTO Town (id, pwd, tel, birth) VALUES (@ID, @PWD, @Tel, @Birth)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", id);
                    command.Parameters.AddWithValue("@PWD", pwd);
                    command.Parameters.AddWithValue("@Tel", tel);
                    command.Parameters.AddWithValue("@Birth", birth);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show(id + "님 환영합니다!", "회원가입 완료", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("회원가입에 실패했습니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }


        //취소
        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
