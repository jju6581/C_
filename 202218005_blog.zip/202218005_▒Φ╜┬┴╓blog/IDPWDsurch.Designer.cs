﻿namespace _202218005_김승주blog
{
    partial class IDPWDsurch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Tel2 = new System.Windows.Forms.TextBox();
            this.ID = new System.Windows.Forms.TextBox();
            this.Birth = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Tel = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnYes = new System.Windows.Forms.Button();
            this.btnYes2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Tel2
            // 
            this.Tel2.Location = new System.Drawing.Point(97, 348);
            this.Tel2.Name = "Tel2";
            this.Tel2.Size = new System.Drawing.Size(200, 21);
            this.Tel2.TabIndex = 42;
            this.Tel2.Text = "000-0000-0000";
            // 
            // ID
            // 
            this.ID.Location = new System.Drawing.Point(97, 299);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(200, 21);
            this.ID.TabIndex = 44;
            // 
            // Birth
            // 
            this.Birth.Location = new System.Drawing.Point(97, 137);
            this.Birth.Name = "Birth";
            this.Birth.Size = new System.Drawing.Size(200, 21);
            this.Birth.TabIndex = 43;
            this.Birth.Text = "0000-00-00";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 357);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 38;
            this.label6.Text = "전화번호";
            // 
            // Tel
            // 
            this.Tel.Location = new System.Drawing.Point(97, 86);
            this.Tel.Name = "Tel";
            this.Tel.Size = new System.Drawing.Size(200, 21);
            this.Tel.TabIndex = 45;
            this.Tel.Text = "000-0000-0000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 308);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 12);
            this.label5.TabIndex = 40;
            this.label5.Text = "ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 39;
            this.label3.Text = "생년월일";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 41;
            this.label4.Text = "전화번호";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 18F);
            this.label2.Location = new System.Drawing.Point(126, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 24);
            this.label2.TabIndex = 37;
            this.label2.Text = "ID 찾기";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 18F);
            this.label1.Location = new System.Drawing.Point(106, 252);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 24);
            this.label1.TabIndex = 36;
            this.label1.Text = "PWD 찾기";
            // 
            // btnYes
            // 
            this.btnYes.BackColor = System.Drawing.SystemColors.Window;
            this.btnYes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnYes.Location = new System.Drawing.Point(130, 180);
            this.btnYes.Name = "btnYes";
            this.btnYes.Size = new System.Drawing.Size(75, 25);
            this.btnYes.TabIndex = 46;
            this.btnYes.Text = "확인";
            this.btnYes.UseVisualStyleBackColor = false;
            this.btnYes.Click += new System.EventHandler(this.btnYes_Click);
            // 
            // btnYes2
            // 
            this.btnYes2.BackColor = System.Drawing.SystemColors.Window;
            this.btnYes2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnYes2.Location = new System.Drawing.Point(130, 389);
            this.btnYes2.Name = "btnYes2";
            this.btnYes2.Size = new System.Drawing.Size(75, 25);
            this.btnYes2.TabIndex = 47;
            this.btnYes2.Text = "확인";
            this.btnYes2.UseVisualStyleBackColor = false;
            this.btnYes2.Click += new System.EventHandler(this.btnYes2_Click);
            // 
            // IDPWDsurch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(334, 461);
            this.Controls.Add(this.btnYes2);
            this.Controls.Add(this.btnYes);
            this.Controls.Add(this.Tel2);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.Birth);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Tel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.Window;
            this.Name = "IDPWDsurch";
            this.Text = "IDPWDsurch";
            this.Load += new System.EventHandler(this.IDPWDsurch_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Tel2;
        private System.Windows.Forms.TextBox ID;
        private System.Windows.Forms.TextBox Birth;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Tel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnYes;
        private System.Windows.Forms.Button btnYes2;
    }
}