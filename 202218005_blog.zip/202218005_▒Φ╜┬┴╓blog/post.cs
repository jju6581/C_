﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _202218005_김승주blog
{
    public partial class post : Form
    {
        private string userID;
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";
        private List<(string id, string memo, DateTime createdAt)> memoData;
        private int currentIndex;
        public event Action<string, string> UpdateTimelineLabelAndTextBox;
        public event Action<string, string> MemoUpdated;
        public event Action<string> MemoDeleted;


        public post(string userID)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.userID = userID;

            LoadMemoData();
            DisplayMemoData();
        }

        // db로부터 해당유저의 메모 데이터를 조회
        private void LoadMemoData()
        {
            memoData = new List<(string id, string memo, DateTime createdAt)>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT id, memo, created_at FROM Memo WHERE id = @userID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userID", userID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string id = reader.GetString(0);
                            string memo = reader.GetString(1);
                            DateTime createdAt = reader.GetDateTime(2);
                            memoData.Add((id, memo, createdAt));
                        }
                    }
                }
            }

            currentIndex = 0;
        }

        //메모를 화면에 표시
        private void DisplayMemoData()
        {
            if (memoData.Count > 0)
            {
                string memo = memoData[currentIndex].memo;
                RichTextBox1.Text = memo;
                Label10.Text = $"Memo {currentIndex + 1} of {memoData.Count}";
            }
            else
            {
                RichTextBox1.Text = string.Empty;
                Label10.Text = "No Memo Data";
            }
        }

        //메모삭제
        private void delete_Click(object sender, EventArgs e)
        {
            if (currentIndex < memoData.Count)
            {
                string memoId = memoData[currentIndex].id;
                DateTime createdAt = memoData[currentIndex].createdAt;

                DialogResult result = MessageBox.Show("메모를 삭제하시겠습니까?", "메모 삭제", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "DELETE FROM Memo WHERE id = @memoId AND created_at = @createdAt";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@memoId", memoId);
                            command.Parameters.AddWithValue("@createdAt", createdAt);

                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("메모가 성공적으로 삭제되었습니다.");

                                memoData.RemoveAt(currentIndex);
                                if (currentIndex >= memoData.Count)
                                    currentIndex--;

                                DisplayMemoData(); // 삭제 후 다음 메모 표시
                                MemoDeleted?.Invoke(memoId); // MemoDeleted 이벤트 발생
                            }
                            else
                            {
                                MessageBox.Show("메모 삭제에 실패했습니다.");
                            }
                        }
                    }
                }
            }
        }

        //게시글 넘기는 버튼
        private void btnBack_Click(object sender, EventArgs e)
        {
            if (currentIndex > 0)
            {
                currentIndex--;
                DisplayMemoData();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentIndex < memoData.Count - 1)
            {
                currentIndex++;
                DisplayMemoData();
            }
            else
            {
                MessageBox.Show("마지막 메모입니다.");
            }
        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //수정완료버튼
        private void rivise_Click(object sender, EventArgs e)
        {
            if (currentIndex < memoData.Count)
            {
                string memoId = memoData[currentIndex].id;
                DateTime createdAt = memoData[currentIndex].createdAt;

                string updatedMemo = RichTextBox1.Text;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "UPDATE Memo SET memo = @updatedMemo WHERE id = @memoId AND created_at = @createdAt";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@updatedMemo", updatedMemo);
                        command.Parameters.AddWithValue("@memoId", memoId);
                        command.Parameters.AddWithValue("@createdAt", createdAt);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("메모가 성공적으로 수정되었습니다.");
                            memoData[currentIndex] = (memoId, updatedMemo, createdAt);
                            MemoUpdated?.Invoke(memoId, updatedMemo); 
                        }
                        else
                        {
                            MessageBox.Show("메모 수정에 실패했습니다.");
                        }
                    }
                }
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (UpdateTimelineLabelAndTextBox != null)
            {
                string memoId = memoData[currentIndex].id;
                string memo = memoData[currentIndex].memo;

                UpdateTimelineLabelAndTextBox.Invoke(memoId, memo);
            }

            this.Close();
        }
    }
}
