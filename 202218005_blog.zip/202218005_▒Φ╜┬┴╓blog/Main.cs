﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _202218005_김승주blog
{
    public partial class Main : Form
    {
        private Timeline subForm;

        // 데이터베이스 연결
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";

        private int maxIndex;
        private List<(string id, string memo)> memoData;

        public Main()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            subForm = null;
            CheckForIllegalCrossThreadCalls = false;

            // 메모 데이터를 로드 메서드 호출
            LoadMemoData(); 
        }

        // db에서 메모 데이터 로드 메소드
        private void LoadMemoData()
        {
            memoData = new List<(string id, string memo)>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Memo 테이블에서 id와 memo를 조회하여 메모 데이터를 가져오기
                string query = "SELECT id, memo FROM Memo";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // 가져온 데이터 리스트에 추가
                        while (reader.Read())
                        {
                            string id = reader.GetString(0);
                            string memo = reader.GetString(1);
                            memoData.Add((id, memo));
                        }
                    }
                }

                maxIndex = memoData.Count - 1;
            }
        }

        //로그인 버튼
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string userID = ID.Text;
            string password = PWD.Text;

            // id,pwd일치하는지 확인, 틀리면 로그인 실패 알림창
            if (AuthenticateUser(userID, password))
            {
                subForm = new Timeline(userID, this);
                subForm.FormClosed += SubForm_FormClosed;

                // db에서 Memo 로드 표시
                LoadMemoFromDatabase(userID);
               
                maxIndex = memoData.Count - 1;

                subForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("비밀번호 또는 로그인 정보가 다릅니다.", "로그인 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // id,pwd조회
        private bool AuthenticateUser(string userID, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Town WHERE id = @UserID AND pwd = @Password";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@Password", password);

                    int count = (int)command.ExecuteScalar();

                    if (count >= 1)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }

        // db에서 사용자 메모 불러오기
        private string LoadMemoFromDatabase(string userID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT memo FROM Memo WHERE id = @UserID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        return reader["memo"].ToString();
                    }
                }
            }

            return string.Empty;
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 폼이 닫힐 때 subForm이 열려있으면 같이 닫아줌
            if (e.CloseReason == CloseReason.UserClosing && subForm != null && !subForm.IsDisposed)
            {
                subForm.FormClosed -= SubForm_FormClosed; 
                subForm.Close();
            }
        }

        // subForm 닫혔을 때 메인폼 다시 보여주기
        private void SubForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!this.IsDisposed)
            {
                this.Show(); 
            }
        }


        private void Main_Load(object sender, EventArgs e)
        {
        }

        // ID/PWD 찾기
        private void btnSurch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            IDPWDsurch idPwdSurchForm = new IDPWDsurch();
            idPwdSurchForm.Show();
        }

        private void btnInsert_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Insert InsertForm = new Insert();
            InsertForm.Show();
        }
    }
}