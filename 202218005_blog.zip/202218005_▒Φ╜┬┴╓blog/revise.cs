﻿// revise.cs
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _202218005_김승주blog
{
    public partial class revise : Form
    {
        private string userID;

        public revise(string userID)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.userID = userID;

            // 사용자 정보를 로드하여 텍스트박스에 표시
            LoadUserInfo();
        }

        private void LoadUserInfo()
        {
            string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT ID, PWD, Tel, Birth FROM Town WHERE ID = @ID";

                // 유저 ID기반 db에서 해당 유저 정보를 가져옴
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", userID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // 데이터베이스에서 읽은 값을 텍스트박스에 설정
                            ID.Text = reader.GetString(0);
                            PWD.Text = reader.GetString(1);
                            Tel.Text = reader.GetString(2);
                            Birth.Text = reader.GetString(3);
                        }
                    }
                }
            }
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            // 수정된 정보를 가져옴
            string updatedPWD = PWD.Text;
            string updatedTel = Tel.Text;
            string updatedBirth = Birth.Text;

            string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";

            // 데이터베이스 연결을 열고 사용자 정보를 업데이트함
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "UPDATE Town SET PWD = @PWD, Tel = @Tel, Birth = @Birth WHERE ID = @ID";

                // 유저 정보를 업데이트하는 SQL 쿼리 실행
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PWD", updatedPWD);
                    command.Parameters.AddWithValue("@Tel", updatedTel);
                    command.Parameters.AddWithValue("@Birth", updatedBirth);
                    command.Parameters.AddWithValue("@ID", userID);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("정보가 수정되었습니다.");
                    }
                    else
                    {
                        MessageBox.Show("정보 수정에 실패했습니다.");
                    }
                }
                this.Close();
            }
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
