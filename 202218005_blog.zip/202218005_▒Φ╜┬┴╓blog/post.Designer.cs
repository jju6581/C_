﻿namespace _202218005_김승주blog
{
    partial class post
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.RichTextBox1 = new System.Windows.Forms.RichTextBox();
            this.delete = new System.Windows.Forms.Button();
            this.Label10 = new System.Windows.Forms.Label();
            this.rivise = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.Window;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBack.Location = new System.Drawing.Point(19, 252);
            this.btnBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(96, 44);
            this.btnBack.TabIndex = 24;
            this.btnBack.Text = "이전 글";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.SystemColors.Window;
            this.btnNext.FlatAppearance.BorderSize = 0;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnNext.Location = new System.Drawing.Point(262, 252);
            this.btnNext.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(96, 44);
            this.btnNext.TabIndex = 25;
            this.btnNext.Text = "다음 글";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(399, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "_________________________________________________";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 15F);
            this.label3.Location = new System.Drawing.Point(21, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 25);
            this.label3.TabIndex = 20;
            this.label3.Text = "OPEN TOWN";
            // 
            // RichTextBox1
            // 
            this.RichTextBox1.BackColor = System.Drawing.SystemColors.Window;
            this.RichTextBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RichTextBox1.Location = new System.Drawing.Point(19, 114);
            this.RichTextBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RichTextBox1.Name = "RichTextBox1";
            this.RichTextBox1.Size = new System.Drawing.Size(339, 119);
            this.RichTextBox1.TabIndex = 19;
            this.RichTextBox1.Text = "";
            this.RichTextBox1.TextChanged += new System.EventHandler(this.RichTextBox1_TextChanged);
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.SystemColors.Window;
            this.delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.delete.Location = new System.Drawing.Point(301, 80);
            this.delete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(57, 29);
            this.delete.TabIndex = 27;
            this.delete.Text = "삭제";
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(23, 86);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(45, 15);
            this.Label10.TabIndex = 28;
            this.Label10.Text = "label2";
            // 
            // rivise
            // 
            this.rivise.BackColor = System.Drawing.SystemColors.Window;
            this.rivise.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rivise.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rivise.Location = new System.Drawing.Point(238, 80);
            this.rivise.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rivise.Name = "rivise";
            this.rivise.Size = new System.Drawing.Size(57, 29);
            this.rivise.TabIndex = 29;
            this.rivise.Text = "수정";
            this.rivise.UseVisualStyleBackColor = false;
            this.rivise.Click += new System.EventHandler(this.rivise_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.SystemColors.Window;
            this.exit.FlatAppearance.BorderSize = 0;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.exit.Location = new System.Drawing.Point(301, 13);
            this.exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(57, 44);
            this.exit.TabIndex = 30;
            this.exit.Text = "닫기";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // post
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(382, 330);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.rivise);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.RichTextBox1);
            this.ForeColor = System.Drawing.SystemColors.Window;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "post";
            this.Text = "post";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox RichTextBox1;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Label Label10;
        private System.Windows.Forms.Button rivise;
        private System.Windows.Forms.Button exit;
    }
}