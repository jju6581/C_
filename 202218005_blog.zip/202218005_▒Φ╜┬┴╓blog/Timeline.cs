﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _202218005_김승주blog
{
    public partial class Timeline : Form
    {
        private bool isCollapsed;
        private string currentID;
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=CookDB;Trusted_Connection=True;";
        private int currentIndex;
        private int maxIndex;

        private List<(string id, string memo, DateTime createdAt)> memoData;
        private post postForm;
        private Main mainForm;
        private string userID;


        // 메모 데이터 가져오기
        private void LoadMemoData()
        {
            memoData = new List<(string id, string memo, DateTime createdAt)>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Memo 테이블에서 메모 데이터를 생성일 기준 내림차순 조회
                string query = "SELECT id, memo, created_at FROM Memo ORDER BY created_at DESC";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string id = reader.GetString(0);
                            string memo = reader.GetString(1);
                            DateTime createdAt = reader.GetDateTime(2);
                            memoData.Add((id, memo, createdAt));
                        }
                    }
                }

                // Memo 테이블의 행 수를 조회해 maxIndex 설정
                using (SqlCommand maxIndexCommand = new SqlCommand("SELECT COUNT(*) FROM Memo", connection))
                {
                    maxIndex = (int)maxIndexCommand.ExecuteScalar() - 1;
                }
            }
        }
        public Timeline(string userID, Main mainForm)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.currentID = userID;
            this.mainForm = mainForm;

            Timeline timelineForm = this;

            flowLayoutPanel1.Visible = false;
            currentID = userID;
            currentIndex = 0;

            LoadMemoData();
            DisplayMemoData();
        }

        // 현재 메모 데이터 표시
        private void DisplayMemoData()
        {
            if (memoData != null && memoData.Count > 0)
            {
                (string id, string memo, DateTime createdAt) = memoData[currentIndex];
                Label10.Text = $"Memo {currentIndex + 1} of {maxIndex + 1} - ID: {id}";
                RichTextBox1.Text = memo;
            }
            else
            {
                Label10.Text = "No Memo Data";
                RichTextBox1.Text = string.Empty;
            }
        }

        // 메모 내용에 대한 Getter 및 Setter
        /*public string MemoText
        {
            get { return RichTextBox1.Text; }
            set { RichTextBox1.Text = value; }
        }

        // ID 라벨에 대한 Getter 및 Setter
        public string IDLabelText
        {
            get { return Label10.Text; }
            set { Label10.Text = value; }
        }*/

        private void button3_Click(object sender, EventArgs e)
        {
            revise reviseForm = new revise(currentID);
            reviseForm.Show();
        }

        //메뉴확장/축소
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                Dropdown.Height += 10;
                if (Dropdown.Size == Dropdown.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                Dropdown.Height -= 10;
                if (Dropdown.Size == Dropdown.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        //메뉴확장/축소
        private void button3_Click_1(object sender, EventArgs e)
        {
            timer1.Start();
        }

        // 메뉴 토글 버튼 클릭 시 
        private void showMenu_Click(object sender, EventArgs e)
        {
            if (flowLayoutPanel1.Visible)
            {
                flowLayoutPanel1.Hide();
                timer1.Stop();
                isCollapsed = true;
                Dropdown.Height = Dropdown.MinimumSize.Height;
            }
            else
            {
                flowLayoutPanel1.Show();
                timer1.Start();
                isCollapsed = false;
            }

        }

        private void write_Click(object sender, EventArgs e)
        {
            WriteForm writeForm = new WriteForm(currentID, this); // Timeline 폼의 인스턴스 전달
            writeForm.UpdateTimelineLabelAndTextBox += (id, memo) => UpdateMemoData(id, memo); 
            writeForm.Show();
        }

        // 메모 작성,수정 후 업데이트
        private void UpdateMemoData(string id, string memo)
        {
            // Memo 데이터 업데이트
            memoData.Clear();
            LoadMemoData();

            // 메모 업데이트
            DisplayMemoData();
        }

        // 이전 메모 버튼 메모 넘어가도록
        private void btnBack_Click(object sender, EventArgs e)
        {
            if (currentIndex > 0)
            {
                currentIndex--;
                DisplayMemoData();
            }

        }

        // 다음 메모 버튼 메모 넘어가도록
        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentIndex < maxIndex)
            {
                currentIndex++;
                DisplayMemoData();
            }
            Controls.SetChildIndex(btnNext, 0);
        }

        private void profile_Click(object sender, EventArgs e)
        {
            profile profileForm = new profile(currentID);
            profileForm.Show();
        }
        private void Post_Click(object sender, EventArgs e)
        {
            postForm = new post(currentID);
            postForm.Show();
        }


        private void logout_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            mainForm.Show();
            mainForm.Activate();
        }

        //탈퇴
        private void delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("정말 탈퇴하시겠습니까?", "삭제 확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                bool hasMemoData = (memoData != null && memoData.Count > 0);

                if (hasMemoData)
                {
                    // memoData에서 해당 계정 정보 삭제
                    string id = memoData[currentIndex].id;
                    memoData.RemoveAt(currentIndex);

                    // 순서조정
                    if (currentIndex >= memoData.Count)
                        currentIndex--;

                    // Memo 테이블에서 해당 계정 정보 삭제
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        // Memo 테이블에서 해당 id에 대한 행 삭제
                        string deleteMemoQuery = "DELETE FROM Memo WHERE id = @ID";
                        using (SqlCommand deleteMemoCommand = new SqlCommand(deleteMemoQuery, connection))
                        {
                            deleteMemoCommand.Parameters.AddWithValue("@ID", id);
                            deleteMemoCommand.ExecuteNonQuery();
                        }
                    }
                }

                // Town 테이블에서 해당 계정 정보 삭제
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Town 테이블에서 해당 id에 대한 행 삭제
                    string deleteAccountQuery = "DELETE FROM Town WHERE id = @ID";
                    using (SqlCommand deleteAccountCommand = new SqlCommand(deleteAccountQuery, connection))
                    {
                        deleteAccountCommand.Parameters.AddWithValue("@ID", currentID);
                        deleteAccountCommand.ExecuteNonQuery();
                    }
                }

                // 메모 업데이트
                DisplayMemoData();
                Main mainForm = Application.OpenForms.OfType<Main>().FirstOrDefault();
                if (mainForm != null)
                {
                    mainForm.Show();
                }
                this.Close(); 
            }
        }

        //메모가 제대로 로드되지 않았을때 새로고침 버튼
        private void rere_Click(object sender, EventArgs e)
        {
            LoadMemoData();
            DisplayMemoData();
        }

    }
}
