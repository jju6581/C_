﻿namespace _202218005_김승주blog
{
    partial class Timeline
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.RichTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.profile = new System.Windows.Forms.Button();
            this.Post = new System.Windows.Forms.Button();
            this.Dropdown = new System.Windows.Forms.FlowLayoutPanel();
            this.ID = new System.Windows.Forms.Button();
            this.revise = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.logout = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Label10 = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.write = new System.Windows.Forms.Button();
            this.showMenu = new System.Windows.Forms.Button();
            this.rere = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.Dropdown.SuspendLayout();
            this.SuspendLayout();
            // 
            // RichTextBox1
            // 
            this.RichTextBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RichTextBox1.Enabled = false;
            this.RichTextBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RichTextBox1.Location = new System.Drawing.Point(19, 115);
            this.RichTextBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RichTextBox1.Name = "RichTextBox1";
            this.RichTextBox1.Size = new System.Drawing.Size(339, 119);
            this.RichTextBox1.TabIndex = 0;
            this.RichTextBox1.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 15F);
            this.label3.Location = new System.Drawing.Point(21, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "OPEN TOWN";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(399, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "_________________________________________________";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.profile);
            this.flowLayoutPanel1.Controls.Add(this.Post);
            this.flowLayoutPanel1.Controls.Add(this.Dropdown);
            this.flowLayoutPanel1.Controls.Add(this.logout);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 330);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(420, 246);
            this.flowLayoutPanel1.TabIndex = 20;
            this.flowLayoutPanel1.TabStop = true;
            // 
            // profile
            // 
            this.profile.FlatAppearance.BorderSize = 0;
            this.profile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.profile.Font = new System.Drawing.Font("굴림", 10F);
            this.profile.Location = new System.Drawing.Point(3, 4);
            this.profile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.profile.Name = "profile";
            this.profile.Size = new System.Drawing.Size(171, 49);
            this.profile.TabIndex = 12;
            this.profile.Text = "프로필";
            this.profile.UseVisualStyleBackColor = true;
            this.profile.Click += new System.EventHandler(this.profile_Click);
            // 
            // Post
            // 
            this.Post.FlatAppearance.BorderSize = 0;
            this.Post.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Post.Font = new System.Drawing.Font("굴림", 10F);
            this.Post.Location = new System.Drawing.Point(180, 4);
            this.Post.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Post.Name = "Post";
            this.Post.Size = new System.Drawing.Size(171, 49);
            this.Post.TabIndex = 12;
            this.Post.Text = "게시글 관리";
            this.Post.UseVisualStyleBackColor = true;
            this.Post.Click += new System.EventHandler(this.Post_Click);
            // 
            // Dropdown
            // 
            this.Dropdown.Controls.Add(this.ID);
            this.Dropdown.Controls.Add(this.revise);
            this.Dropdown.Controls.Add(this.delete);
            this.Dropdown.Location = new System.Drawing.Point(3, 61);
            this.Dropdown.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Dropdown.MaximumSize = new System.Drawing.Size(171, 169);
            this.Dropdown.MinimumSize = new System.Drawing.Size(171, 52);
            this.Dropdown.Name = "Dropdown";
            this.Dropdown.Size = new System.Drawing.Size(171, 52);
            this.Dropdown.TabIndex = 13;
            // 
            // ID
            // 
            this.ID.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ID.FlatAppearance.BorderSize = 0;
            this.ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ID.Font = new System.Drawing.Font("굴림", 10F);
            this.ID.Location = new System.Drawing.Point(3, 4);
            this.ID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(171, 49);
            this.ID.TabIndex = 12;
            this.ID.Text = "계정 관리";
            this.ID.UseVisualStyleBackColor = false;
            this.ID.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // revise
            // 
            this.revise.FlatAppearance.BorderSize = 0;
            this.revise.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.revise.Location = new System.Drawing.Point(3, 61);
            this.revise.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.revise.Name = "revise";
            this.revise.Size = new System.Drawing.Size(168, 49);
            this.revise.TabIndex = 12;
            this.revise.Text = "정보 수정";
            this.revise.UseVisualStyleBackColor = true;
            this.revise.Click += new System.EventHandler(this.button3_Click);
            // 
            // delete
            // 
            this.delete.FlatAppearance.BorderSize = 0;
            this.delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delete.Location = new System.Drawing.Point(3, 118);
            this.delete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(168, 49);
            this.delete.TabIndex = 13;
            this.delete.Text = "회원 탈퇴";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // logout
            // 
            this.logout.FlatAppearance.BorderSize = 0;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("굴림", 10F);
            this.logout.Location = new System.Drawing.Point(180, 61);
            this.logout.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(171, 49);
            this.logout.TabIndex = 14;
            this.logout.Text = "로그아웃";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("굴림", 11F);
            this.Label10.Location = new System.Drawing.Point(22, 85);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(54, 19);
            this.Label10.TabIndex = 17;
            this.Label10.Text = "name";
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.SystemColors.Window;
            this.btnNext.FlatAppearance.BorderSize = 0;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnNext.Location = new System.Drawing.Point(182, 254);
            this.btnNext.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(96, 44);
            this.btnNext.TabIndex = 18;
            this.btnNext.Text = "다음 글";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.Window;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBack.Location = new System.Drawing.Point(19, 254);
            this.btnBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(96, 44);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "이전 글";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // write
            // 
            this.write.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.write.BackgroundImage = global::_202218005_김승주blog.Properties.Resources.write;
            this.write.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.write.FlatAppearance.BorderSize = 0;
            this.write.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.write.Location = new System.Drawing.Point(307, 248);
            this.write.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.write.Name = "write";
            this.write.Size = new System.Drawing.Size(46, 50);
            this.write.TabIndex = 16;
            this.write.TabStop = false;
            this.write.UseVisualStyleBackColor = false;
            this.write.Click += new System.EventHandler(this.write_Click);
            // 
            // showMenu
            // 
            this.showMenu.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.showMenu.BackgroundImage = global::_202218005_김승주blog.Properties.Resources.menuwhite;
            this.showMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.showMenu.FlatAppearance.BorderSize = 0;
            this.showMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.showMenu.ForeColor = System.Drawing.SystemColors.Window;
            this.showMenu.Location = new System.Drawing.Point(313, 9);
            this.showMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.showMenu.Name = "showMenu";
            this.showMenu.Size = new System.Drawing.Size(46, 50);
            this.showMenu.TabIndex = 14;
            this.showMenu.UseVisualStyleBackColor = false;
            this.showMenu.Click += new System.EventHandler(this.showMenu_Click);
            // 
            // rere
            // 
            this.rere.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rere.Location = new System.Drawing.Point(279, 80);
            this.rere.Name = "rere";
            this.rere.Size = new System.Drawing.Size(80, 29);
            this.rere.TabIndex = 21;
            this.rere.Text = "새로고침";
            this.rere.UseVisualStyleBackColor = true;
            this.rere.Click += new System.EventHandler(this.rere_Click);
            // 
            // Timeline
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(382, 597);
            this.Controls.Add(this.rere);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.write);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.showMenu);
            this.Controls.Add(this.RichTextBox1);
            this.ForeColor = System.Drawing.SystemColors.Window;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Timeline";
            this.Text = "Timeline";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.Dropdown.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox RichTextBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button profile;
        private System.Windows.Forms.Button Post;
        private System.Windows.Forms.Button ID;
        private System.Windows.Forms.FlowLayoutPanel Dropdown;
        private System.Windows.Forms.Button revise;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button showMenu;
        private System.Windows.Forms.Button write;
        private System.Windows.Forms.Label Label10;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button rere;
    }
}